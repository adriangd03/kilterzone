# ToDo
- Acabar wireframe
- Mockup
- Rutes
    - crear el resto de svg
    - Limpiar los svgs
    - Afegir les noves comprobacions
    - Tener en cuenta que habra rutas que es podrán haer en más de un modelo
    - Vista de ruta 
    - Vista en el home de rutas populares y de amigos
    - Ver tus rutas 
    - Ver las rutas de otros usuarios en su perfil
- Busqueda de rutas y usuarios
    - Añadir busqueda de usuarios





# Pàgines
- Home 
    - Si no estás iniciat de sessió en la homepage et sortirà una breu explicació de la pàgina, rutes populars,  rutes que han sortit noves i també sortirà recomenacions de rutes si estàs iniciat de sessió
    - Cercació d'usuaris i rutes
- Login
    - Login tradicioinal i amb Oauth de google
- Registre
    - Registre normal i amb Oauth de google
- Configuració
    - Canviar imatge de avatar, nom de usuari, contrasenya.
    - Configuració de la privacitat.
- Perfil de altres usuaris
    - Veure la seva imatge de perfil, biografía, rutes creades per ell, rutes que li han agradat i ha marcat com fet.
    - Começar a seguir/Afegir com amic.
    - Bloquar. (Probablement no és farà)
- Perfil propi
    - Podràs veure el teu perfil 
- Ruta
    - Marcar com feta, donar like i comentar
    - Veure la informació de la ruta
- Creació de la ruta
    - Al crear ruta escolliràs el model de la paret, la inclinació a que és supossada de fer feta, dificultat que et sembla i descripció.
    - Podràs escollir si fer-la publica o guardar-la com privada.

# Com instal·lar el projecte
## Passos per la instal·lació del projecte

# Millores
- Afegir opció per bloquejar a usuaris.


