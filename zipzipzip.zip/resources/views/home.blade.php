@extends('layouts.master')

@section('title', 'Home')

@auth
@section('scripts')
@vite(['resources/js/home.js'])
@endsection
@endauth
@section('content')


@endsection