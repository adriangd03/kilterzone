<!-- Offcanvas Chat -->

<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasUsuaris" data-bs-backdrop="false" aria-labelledby="offcanvasUsuarisLabel">



    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasExampleLabel">Usuaris</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body h-100">
        <div class="row h-100 ">
            <div class="col-12">
                <div class="row mb-3">
                    <div class="col-12">

                        <ul class="nav nav-tabs" id="usersTab">

                            <li class="nav-item">
                                <a class="nav-link active" id="usuaris-tab" data-bs-toggle="tab" href="#usuaris" role="tab" aria-controls="usuaris" aria-selected="true">Usuaris</a>
                            </li>
                            <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item position-relative">
                                <a class="nav-link" id="solAmics-tab" data-bs-toggle="tab" href="#solAmics" role="tab" aria-controls="solAmics" aria-selected="false">Sol·licituds d'amistat</a>

                                <span name="solAmicsBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" <?php if($totalFriendRequests == 0): ?> style="display: none;" <?php endif; ?>>
                                    <span name="solAmicBadgeValue"> <?php echo e($totalFriendRequests); ?></span>
                                    <span class="visually-hidden">Sol·licituds d'amistat</span>
                                </span>
                            </li>
                            <?php endif; ?>
                        </ul>
                        <div class="tab-content" id="usersTabContent">
                            <div class="tab-pane fade show active" id="usuaris" role="tabpanel" aria-labelledby="usuaris-tab">
                                <div class="card">
                                    <div class="card-header d-flex">
                                        <h4>Usuaris</h4>
                                        <input type="text" class="form-control ms-auto w-25" id="searchUser" name="searchUser" placeholder="Cerca usuari">

                                    </div>
                                    <div class="card-body h-100 mh-100 ">
                                        <div id="users" class="users-list row mh-100 p-3">
                                            <?php $__currentLoopData = $notFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                            
                                            
                                            <a id="divNotFriend-<?php echo e($user->id); ?>" href="<?php echo e(route('perfil', $user->id)); ?>" class=" text-decoration-none rounded user-hover">
                                                <div  class="row m-1 w-100 pt-2 pb-2 ">
                                                    <div class="col align-content-center">
                                                        <div class="d-flex d-inine align-content-center align-items-center">
                                                            <img class="rounded-circle" src="<?php echo e($user->avatar); ?>" alt="avatar 1" style="width: 45px; height: 45px;">
                                                            <div class="card-text ms-2">
                                                                <div class="friend-username text-dark"><?php echo e($user->username); ?></div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <?php if(auth()->guard()->check()): ?>
                                                    <div class="col align-content-center">
                                                        <?php if($user->sentFriendRequest): ?>
                                                        <span class="btn btn-primary border border-white disabled">Sol·licitud enviada</span>
                                                        <?php else: ?>
                                                        <form name="formSolAmic" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="friend_id" value="<?php echo e($user->id); ?>">
                                                            <button class="btn btn-primary border border-white" type="submit">Afegir amic</button>
                                                        </form>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php endif; ?>

                                                </div>
                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <div class="tab-pane fade" id="solAmics" role="tabpanel" aria-labelledby="solAmics-tab">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Sol·licituds d'amistat</h4>
                                    </div>
                                    <div class="card-body h-100 mh-100 ">
                                        <div id="DivSolAmics" class="users-list  row mh-100 p-3">
                                            <?php $__currentLoopData = $friendRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friendRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-4" name="divSolAmic">
                                                <a href="<?php echo e(route('perfil', $friendRequest->user->id)); ?>" class="text-decoration-none">
                                                    <div id="solAmic-<?php echo e($friendRequest->user->id); ?>" class="col-12 text-center p-2  rounded user-hover ">
                                                        <div class="user-info">
                                                            <img class="rounded-circle" src="<?php echo e($friendRequest->user->avatar); ?>" alt="avatar 1" style="width: 45px; height: 45px;">
                                                            <div class="card-text">
                                                                <div class="fw-bold text-dark"><?php echo e($friendRequest->user->username); ?></div>
                                                            </div>
                                                            <form name="formAcceptarSolAmic" action="acceptarSolicitudAmic" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="friend_id" value="<?php echo e($friendRequest->user->id); ?>">
                                                                <button class="btn btn-primary border border-white" type="submit">Acceptar</button>
                                                            </form>
                                                            <form name="formRebutjarSolAmic" action="rebutjarSolicitudAmic" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="friend_id" value="<?php echo e($friendRequest->user->id); ?>">
                                                                <button class="btn btn-danger border border-white" type="submit">Rebutjar</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($friendRequests) == 0): ?>
                                            <div class="text-center fw-bold">
                                                No tens sol·licituds d'amistat
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>


                    </div>

                </div>



            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\kilterzone\resources\views/partials/user.blade.php ENDPATH**/ ?>