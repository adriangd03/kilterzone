<!-- CSS -->
<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?><?php /**PATH C:\laragon\www\kilterzone\resources\views/partials/styles.blade.php ENDPATH**/ ?>