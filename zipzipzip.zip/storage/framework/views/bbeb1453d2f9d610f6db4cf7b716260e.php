<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    
    <?php if(auth()->guard()->check()): ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/chatFriends.js'); ?>
    <?php endif; ?>

</head>

<body class="bg-body">
    <div id="body">

        <div class="shell">

            <div id="left" >
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="mid" style="min-width: 0;">

                <?php echo $__env->yieldContent('content'); ?>

                <div id="divToasts" class="toast-container position-fixed top-5 start-5 p-3">
                    <?php if(session('success')): ?>
                    <div class=" toast show text-white bg-success" role="alert" aria-live="assertive" aria-atomic="true" autohide="true" >
                        <div class="toast-header">
                            <strong class="me-auto">Notificació</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close">
                        </div>
                        <div class="toast-body">
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class=" toast show align-items-center text-white bg-primary border-0 bg-danger" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        <strong class="me-auto">KilterZone</strong>
                        <small>now</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close">
                    </div>
                    <div class="toast-body">
                        <?php echo e(session('error')); ?>

                    </div>
                </div>

                <?php endif; ?>



            </div>
        </div>

    </div>
    </div>
    </div>
</body>

</html><?php /**PATH C:\laragon\www\kilterzone\resources\views/layouts/master.blade.php ENDPATH**/ ?>