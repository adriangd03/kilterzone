<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurar Contrasenya</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>

<body>


    <div class="container py-3">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center ">
                        Canviar contrasenya

                    </div>

                    <form method="POST" action="<?php echo e(route('restaurarContrasenya.post')); ?>">
                        <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <!-- Camp de email -->
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php $__errorArgs = ['email','restaurar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2" name="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Camp de password i de confirmació de password -->
                            <div class="mb-3">
                                <label for="password" class="form-label ">Nova contrasenya</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <?php $__errorArgs = ['password','restaurar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2" name="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="mb-3">
                                <label for="password_confirmation" class="form-label ">Confirmar contrasenya</label>
                                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                                <?php $__errorArgs = ['password_confirmation','restaurar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2" name="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" name="token" value="<?php echo e($token); ?>">



                            <?php $__errorArgs = ['error','restaurar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2" name="error"> <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="mb-3 mt-2">
                                <button type="submit" class="btn btn-primary">
                                    Restaurar contrasenya
                                </button>
                            </div>
                    </form>

                </div>

                <?php if(session('success')): ?>

                <div class="alert alert-success mt-2" name="error"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="alert alert-danger mt-2" name="error"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
</body>

</html><?php /**PATH C:\laragon\www\kilterzone\resources\views/restaurar.blade.php ENDPATH**/ ?>