

<?php $__env->startSection('title', 'Configuració'); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/configuracio.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col">
            <h1>Configuració</h1>

            <hr class="mt-3 mb-3">

            <div class="card border-0">
                <div class="card-body">
                    <h5 class="card-title">Editar perfil</h5>
                    <div class="row mt-3 mb-3">
                        <div class="col">
                            <div class="d-flex ">
                                <h6>Imatge de perfil</h6>
                            </div>
                            <div class="d-flex align-items-center">
                                <img src="<?php echo e(Auth::user()->avatar); ?>" class="rounded-circle" alt="avatar" style="width: 60px; height: 60px;">
                                <span class="ms-2 text-muted"><?php echo e(Auth::user()->username); ?></span>
                                <button type="button" class="btn btn-secondary ms-4 " data-bs-toggle="modal" data-bs-target="#modalAvatar">Canviar</button>
                            </div>

                            <?php $__errorArgs = ['avatar', 'actualitzarImatgePerfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo e(route('actualitzarDades')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="username" class="form-label">Nom d'usuari</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo e(old('username', Auth::user()->username)); ?>">
                            <?php $__errorArgs = ['username', 'actualitzarDades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Descripció</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php echo e(old('description', Auth::user()->description)); ?></textarea>
                            <?php $__errorArgs = ['description', 'actualitzarDades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Actualitzar</button>
                    </form>
                </div>
            </div>
            <hr class="mt-3 mb-3">
            <div class="card border-0">
                <div class="card-body">
                    <h5 class="card-title">Canviar contrasenya</h5>
                    <form method="POST" action="<?php echo e(route('actualitzarContrasenya')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="old_password" class="form-label">Contrasenya actual</label>
                            <input type="password" class="form-control" id="old_password" name="old_password">
                            <?php $__errorArgs = ['old_password', 'actualitzarContrasenya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Nova contrasenya</label>
                            <input type="password" class="form-control" id="password" name="password">
                            <?php $__errorArgs = ['password', 'actualitzarContrasenya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">Repeteix la nova contrasenya</label>
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
                            <?php $__errorArgs = ['password_confirmation', 'actualitzarContrasenya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <button type="submit" class="btn btn-primary">Canviar contrasenya</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</div>


<!-- ModalAvatar -->
<div class="modal fade" id="modalAvatar" tabindex="-1" aria-labelledby="modalAvatarLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header ">
                <h4 class="modal-title m-auto" id="modalAvatarLabel">Canviar imatge de perfil</h4>

            </div>
            <div class="modal-body p-0">
                <button id="btnAvatar" type="button" class="btn rounded-0  user-hover w-100 border border-bottom border-top pt-3 pb-3 fs-5 p-1 text-center text-primary ">Pujar imatge</button>
                <form method="POST" action="<?php echo e(route('eliminarImatgePerfil')); ?>">
                    <?php echo csrf_field(); ?>
                    <button id="btnEliminarAvatar" type="submit" class="btn rounded-0 text-danger w-100 border border-bottom user-hover pt-3 pb-3 fs-5 p-1 text-center mt-0">Eliminar imatge actual</button>
                </form>
                
                <button type="button" class="btn rounded-top-0 w-100 border border-bottom user-hover pt-3 pb-3 fs-5 p-1 text-center mt-0" data-bs-dismiss="modal" aria-label="Close">Cancel·lar</button>
                <form id="formAvatar" method="POST" action="<?php echo e(route('actualitzarImatgePerfil')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="file" id="avatar" name="avatar" class="d-none">
                </form>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kilterzone\resources\views/configuracio.blade.php ENDPATH**/ ?>